package spark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.Row;

public class SparkKafkaDriver {

    public static void main(String[] args) {
        SparkSession spark = SparkSession
                .builder()
                .appName("Spark kafka application")
                .master("local")
                .getOrCreate();

        //hardcoding below things..but will pass as arguentm or property file
        String path = "";
        String brokerList = "host:9092,host1:9092";
        String topic = "topicname";
        Dataset<Row> ds = readDf(spark, path);
        SparkProducer.pushMessages(ds,brokerList,topic);
    }

   public static Dataset<Row> readDf( SparkSession spark ,String path){
       Dataset<Row> ds = spark.read().option("header","true").csv(path);
       return  ds;
   }

}
