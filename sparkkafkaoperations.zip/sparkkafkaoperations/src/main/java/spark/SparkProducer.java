package spark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class SparkProducer {

    public static void pushMessages(Dataset<Row> df,String brokers,String topic){
               df
                .selectExpr("CAST(col AS STRING) AS key", "to_json(struct(*)) AS value")
                 .write()
                .format("kafka")
                .option("kafka.bootstrap.servers", brokers)
                .option("topic", topic)
                //.option("checkpointLocation", "/path/to/HDFS/dir")
                .save();
    }
}
