package com.test.kafka.producer.resource;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("kafka")
public class KafkaProducer {

    @Autowired
    private KafkaTemplate<String, JSONObject> kafkaTemplate;

    private static final String TOPIC = "Kafka_Example";

    @GetMapping("/publish/{message}")
    public String post(@PathVariable("message") final String message) {

        try {
            System.out.println(message);
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(message);
            System.out.println(json);
            kafkaTemplate.send(TOPIC, json);

        }catch (Exception err){
          err.printStackTrace();
        }


        return "Published successfully";
    }
}
